package src;

public class Generation 
{
	protected enum keyType
		{
				PARENT,
				CHILD,
				ANY
		};
			
	private final int ONECHILD = 1;
	private final int CHILDOFFSET = 6;
	private final int CHILDGEN = 6;
	private final int PARENTGEN = 6;
	private final int ALLGEN = 12;
	private final int MAXDEPTH = 10;
	
	private String Map[] = 
		{
				//Parents
				"Close to Wall",
				"Far from Wall",
				"Do2 far far",
				"Do2 far close",
				"Do2 close far",
				"Do2 close close",
				//Children
				"Go Forward",
				"Turn Right",
				"Turn Left",
				"Backup",
				"Turn Parallel to Position",
				"Turn Square with Wall"
		};
	
	/*
	 * 
	 */
	
	public Node createNode(int depth)
	{
		Node node;
		if(depth<MAXDEPTH)
		{	
			if(Math.random()>0.6)
				node = createChild(depth);
			else
				node = createParent(depth);
		}
		else
			node = createChild(depth);
		node.setDepth(depth);
		return node;
	}
	
	private Node createParent(int depth)
	{
		Node p = new Node(generateKey(keyType.PARENT));
		//create first child
		p.setChild1(createNode(depth+1));
		//if two children create second	
		if(p.getKey()>ONECHILD)
			p.setChild2(createNode(depth+1));
		return p;
	}
	
	private Node createChild(int depth)
	{
		Node child = new Node(generateKey(keyType.CHILD));
		return child;
	}
	
	int generateKey(keyType type)
	{
		int key = 0;
		switch(type)
		{
		case PARENT:
			//generate a number that corresponds to a parent
			key = (int) (Math.random()*PARENTGEN);
			break;
		case CHILD:
			//generate a number that corresponds to a child
			key = (int) (Math.random()*CHILDGEN + CHILDOFFSET);
			break;
		default:
			//generate any type of node
			key = (int) (Math.random()*ALLGEN);
			break;
		}
		return key;
	}
	
	public String getString(int k)
	{
		return Map[k];
	}
	
	public int mapToKey(String line)
	{
		int key = 0;
		while(!line.contains(Map[key]))
			key++;
		return key;
	}
}
