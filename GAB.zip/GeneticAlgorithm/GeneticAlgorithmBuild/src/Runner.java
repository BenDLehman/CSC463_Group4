package src;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Runner 
{
	private Node root;
	private Generation tree = new Generation();
	private File output = new File("output.txt");
	private File input1 = new File("input1.txt");
	private File input2 = new File("input2.txt");
	int node1;
	int node2;
	PrintWriter write;
	public static void main (String [] args) throws FileNotFoundException
	{
		
		//new Runner().random();
		//new Runner().replace();
		new Runner().merge();
	}
	
	public void random() throws FileNotFoundException
	{
		root = tree.createNode(0);
		write = new PrintWriter(output);
		printChild(root);
		write.close();
	}
	
	public void replace() throws FileNotFoundException
	{
		int numNodes = 0;
		
		//count lines from the text file, set numNodes equal to the number of lines
		numNodes = countLines(input1);
		//generate the tree based on the text file
		root = textTree(input1);
		
		node1 = (int)(Math.random()*numNodes);
		System.out.println(node1+1);
		write = new PrintWriter(output);
		root = replaceChild(root);
		printChild(root);
		write.close();
	}
	
	public void merge() throws FileNotFoundException
	{
		//count lines from a text file for first tree, set numNodes1 equal to the number of lines
		int numNodes1 = 0;
		numNodes1 = countLines(input1);
		//count lines from a text file for second tree, set numNodes2 equal to the number of lines
		int numNodes2 = 0;
		numNodes2 = countLines(input2);
		//generate a tree for both text files
		root = textTree(input1);
		Node root2 = textTree(input2);
		
		node1 = (int)(Math.random()*numNodes1);
		node2 = (int)(Math.random()*numNodes2);
		System.out.println(node1+1);
		System.out.println(node2+1);
		
		root = mergeChild(root, root2);
		write = new PrintWriter(output);
		printChild(root);
		write.close();
	}
	
	private Node mergeChild(Node c1, Node c2)
	{
		if(node1==0)
		{
			node1--;
			node2--;
			if(node2==0)
			{
				node2--;
				if(c1.getParent().getChild1()==c1)
				{
					c1.getParent().setChild1(c2);
					c1 = c2;
				}
				else
				{
					c1.getParent().setChild2(c2);
					c1 = c2;
				}
			}
			else if(node2>0)
			{
				if(c2.getChild1() != null)
				{
					mergeChild(c1,c2.getChild1());
					if(c2.getChild2() != null)
					{
						mergeChild(c1,c2.getChild2());
					}
				}
			}
		}
		else if(node1>0)
		{
			node1--;
			if(c1.getChild1() != null)
			{
				mergeChild(c1.getChild1(),c2);
				if(c1.getChild2() != null)
				{
					mergeChild(c1.getChild2(),c2);
				}
			}
		}
		return c1;
	}
		
	private Node replaceChild(Node cn)
	{
		
		if(node1==0)
		{
			node1--;
			if(cn.getParent().getChild1()==cn)
				cn.getParent().setChild1(tree.createNode(cn.getDepth()));
			else
				cn.getParent().setChild2(tree.createNode(cn.getDepth()));
		}
		else if(node1>0)
		{
			node1--;
			if(cn.getChild1() != null)
			{
				replaceChild(cn.getChild1());
				if(cn.getChild2() != null)
				{
					replaceChild(cn.getChild2());
				}
			}
		}
		return cn;
	}
	
	public void hasChild(Node cn)
	{
		if(cn.getChild1() != null)
		{
			hasChild(cn.getChild1());
			if(cn.getChild2() != null)
			{
				hasChild(cn.getChild2());
			}
		}
		return;
	}
	
	public void printChild(Node cn) throws FileNotFoundException
	{
		printNode(cn);
		if(cn.getChild1() != null)
		{
			printChild(cn.getChild1());
			if(cn.getChild2() != null)
			{
				printChild(cn.getChild2());
			}
		}
		return;
	}
	
	private void printNode(Node cn) throws FileNotFoundException
	{

		for(int i = cn.getDepth(); i>0; i--)
		{
			System.out.print("-");
			write.print("-");
		}
		System.out.println(tree.getString(cn.getKey()));
		write.println(tree.getString(cn.getKey()));
	}
	
	private int countLines(File file) throws FileNotFoundException
	{
		Scanner reader = new Scanner(file);
		int lineCount = 0;
		while(reader.hasNextLine())
		{
			reader.nextLine();
			lineCount++;
		}
		reader.close();
		return lineCount;		
	}

	private Node textTree(File file) throws FileNotFoundException
	{
		Scanner reader = new Scanner(file);
		int currentDepth = 0;
		int tempDepth = 0;
		String line;
		
		Node rootnode = new Node(tree.mapToKey(reader.nextLine()));
		rootnode.setDepth(0);
		Node currentNode = rootnode;
		
		while(reader.hasNextLine()&&!(line = reader.nextLine()).isEmpty())
		{
			int position = 0;
			currentDepth=currentNode.getDepth();
			tempDepth = 0;
			Node tempNode = new Node(tree.mapToKey(line));
			
			while(line.charAt(position) == '-')
			{
				position ++;
				tempDepth++;
			}
			if(tempDepth > currentDepth)
			{
				tempNode.setDepth(tempDepth);
				currentNode.setChild1(tempNode);
			}
			else if(tempDepth == currentDepth)
			{
				tempNode.setDepth(tempDepth);
				currentNode.getParent().setChild2(tempNode);
			}
			else
			{
				while(tempDepth<currentDepth)
				{
					currentNode = currentNode.getParent();
					currentDepth = currentNode.getDepth();
				}
				if(tempDepth > currentDepth)
				{
					tempNode.setDepth(tempDepth);
					currentNode.getParent().setChild1(tempNode);
				}
				else if(tempDepth == currentDepth)
				{
					tempNode.setDepth(tempDepth);
					currentNode.getParent().setChild2(tempNode);
				}
			}
			currentNode = tempNode;
		}
		reader.close();
		
		return rootnode;
	}
}
