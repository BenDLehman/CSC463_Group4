public class Runner 
{
	private Node root;
	private Generation tree = new Generation();
	private int nodeReplace;
	private int nodeReplace2;
	public static void main (String [] args)
	{
		new Runner().random();
		//new Runner().replace();
		//new Runner().merge();
	}
	
	public void random()
	{
		root = tree.createNode(0);
		hasChild(root);
	}
	
	public void replace()
	{
		int numNodes = 0;
		//count lines from the text file, set numNodes equal to the number of lines
		//generate the tree based on the text file
		nodeReplace = (int)(Math.random()*numNodes);
		replaceChild(root);
		hasChild(root);
	}
	
	public void merge()
	{
		int numNodes1 = 0;
		//count lines from a text file for first tree, set numNodes1 equal to the number of lines
		int numNodes2 = 0;
		//count lines from a text file for second tree, set numNodes2 equal to the number of lines
		//generate a tree for both text files
		//Node root2 = generated root of tree 2
		int mergeNode1 = (int)(Math.random()*numNodes1);
		int mergeNode2 = (int)(Math.random()*numNodes2);
		//mergeChild(root, root2);
		hasChild(root);
	}
	
	private void mergeChild(Node c1, Node c2)
	{
		if(nodeReplace==0)
		{
			nodeReplace2--;
			if(nodeReplace2==0)
				c1=c2;
			else
				if(c2.getChild1() != null)
				{
					hasChild(c2.getChild1());
					if(c2.getChild2() != null)
					{
						hasChild(c2.getChild2());
					}
				}
		}
		else
		{
			nodeReplace--;
			if(c1.getChild1() != null)
			{
				hasChild(c1.getChild1());
				if(c1.getChild2() != null)
				{
					hasChild(c1.getChild2());
				}
			}
		}
		return;
	}
		
	private void replaceChild(Node cn)
	{
		
		if(nodeReplace==0)
			cn=tree.createNode(cn.getDepth());
		else
		{
			nodeReplace--;
			if(cn.getChild1() != null)
			{
				hasChild(cn.getChild1());
				if(cn.getChild2() != null)
				{
					hasChild(cn.getChild2());
				}
			}
		}
		return;
	}
	
	public void hasChild(Node cn)
	{
		printNode(cn);
		if(cn.getChild1() != null)
		{
			hasChild(cn.getChild1());
			if(cn.getChild2() != null)
			{
				hasChild(cn.getChild2());
			}
		}
		return;
	}
	
	private void printNode(Node cn)
	{
		for(int i = cn.getDepth(); i>0; i--)
		{
			System.out.print("-");
		}
		System.out.println(tree.getString(cn.getKey()));
	}
	
	
}
