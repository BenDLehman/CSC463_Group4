
public class parent extends node
{
	protected node child1;
	protected node child2;
	
}
