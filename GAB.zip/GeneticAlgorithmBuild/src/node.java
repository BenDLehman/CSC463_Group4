

public class node 
{
	protected int depth;
	protected node parent;
	protected node child1;
	protected node child2;
	
	protected node()
	{
		
	}
	
	protected void setChild1(node child)
	{
		
	}
	
	protected void setChild2(node child)
	{
		
	}
}
