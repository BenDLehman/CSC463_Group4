
public class child extends node
{

}
