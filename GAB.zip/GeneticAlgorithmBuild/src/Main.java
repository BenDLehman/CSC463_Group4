
public class Main 
{
	protected enum keyType
		{
				PARENT,
				CHILD,
				ANY
		};
		
	private node root = createParent();
	
	private final int ONECHILD = 1;
	private final int CHILDOFFSET = 6;
	private final int CHILDGEN = 6;
	private final int PARENTGEN = 6;
	private final int ALLGEN = 12;
	
	private String Map[] = 
		{
				//Parents
				"Close to Wall",
				"Far from Wall",
				"Do2 far far",
				"Do2 far close",
				"Do2 close far",
				"Do2 close close",
				//Children
				"Go Forward",
				"Turn Right",
				"Turn Left",
				"Backup",
				"Turn Parallel to Position",
				"Turn Square with Wall"
		};
	
	/*
	 * 
	 */
	
	private node createNode()
	{
		String name = Map[generateKey(keyType.ANY)];
		//check if we need a child
		//create first child if needed
		//create second child if needed
		return null;
	}
	
	private node createParent()
	{
		int key = generateKey(keyType.PARENT);
		String name = Map[generateKey(keyType.PARENT)];
		node parent = new node();
		//create first child
		parent.setChild1(createNode());
		//if two children create second		
		parent.setChild2(createNode());
		return parent;
	}
	
	private node createChild()
	{
		String name = Map[generateKey(keyType.CHILD)];
		return null;
	}
	
	int generateKey(keyType type)
	{
		int key = 0;
		switch(type)
		{
		case PARENT:
			//generate a number that corresponds to a parent
			key = (int) Math.random()*PARENTGEN;
			break;
		case CHILD:
			//generate a number that corresponds to a child
			key = (int) Math.random()*CHILDGEN + CHILDOFFSET;
			break;
		default:
			//generate any type of node
			key = (int) Math.random()*ALLGEN;
			break;
		}
		return key;
	}
}
