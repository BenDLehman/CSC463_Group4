

public class Node 
{
	private int depth;
	private Node parent;
	private Node child1;
	private Node child2;
	private int key;
	
	protected Node(int k)
	{
		key = k;
	}
	
	protected void setChild1(Node child)
	{
		child1=child;
		child1.parent = this;
	}
	
	protected void setChild2(Node child)
	{
		child2=child;
		child2.parent = this;
	}
	
	protected void setDepth(int d)
	{
		depth=d;
	}
	
	protected Node getParent()
	{
		return parent;
	}
	
	protected int getKey()
	{
		return key;
	}
	
	protected int getDepth()
	{
		return depth;
	}
	
	protected Node getChild1()
	{
		return child1;
	}
	
	protected Node getChild2()
	{
		return child2;
	}
}
